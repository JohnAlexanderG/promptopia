export const ROLES = {
  urbanista: { label: 'Urbanista', icon: '▥', building: 'Biblioteca', challenge: 'Diseña una biblioteca para una ciudad de 20 habitantes.' },
  ingeniero: { label: 'Ingeniero', icon: '⚡', building: 'Central solar', challenge: 'Diseña una central solar que abastezca a 20 habitantes.' },
  ecologista: { label: 'Ecologista', icon: '♧', building: 'Jardín comunitario', challenge: 'Diseña un jardín comunitario para una ciudad de 20 habitantes.' },
} as const;
export type Role = keyof typeof ROLES;
export type Evaluation = { score: number; checks: { label: string; passed: boolean; hint: string }[] };
export type Player = { id: string; name: string; role: Role; plot: number; connected: boolean; credits: number; score: number; building: string | null; contributed: boolean };
export type RoomState = { code: string; phase: 'lobby' | 'playing' | 'finished'; endsAt: number | null; players: Player[]; event: { active: boolean; progress: number; goal: number }; log: string[]; serverNow: number };
export type Session = { code: string; token: string; kind: 'host' | 'player'; playerId?: string };
export type Snapshot = { room: RoomState; session: Session; prompt: string; evaluation: Evaluation | null };
export type Reply = { ok: true; data: Snapshot } | { ok: false; error: string };
export type Action = 'create' | 'join' | 'resume' | 'start' | 'submit' | 'build' | 'event' | 'contribute' | 'finish';
