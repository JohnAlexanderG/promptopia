import { randomBytes, randomUUID } from 'node:crypto';
import { ROLES, type Role, type Player, type Evaluation, type RoomState, type Session, type Snapshot } from './types';

type Room = Omit<RoomState, 'serverNow'> & { hostToken: string; tokens: Map<string, string>; drafts: Map<string, { prompt: string; evaluation: Evaluation }>; touchedAt: number };
export class GameError extends Error {}
function assert(condition: unknown, message: string): asserts condition { if (!condition) throw new GameError(message); }
const token = () => randomBytes(24).toString('hex');
export function evaluate(prompt: string, role: Role): Evaluation {
  const p = prompt.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const topic = { urbanista: /biblioteca/, ingeniero: /solar|energia/, ecologista: /jardin|huerto/ }[role];
  const checks = [
    { label: 'Define un rol', passed: /actua como|eres un|eres una|asume el rol/.test(p), hint: 'Indica desde qué especialidad debe responder: «Actúa como…».' },
    { label: 'Tarea y contexto', passed: /disena|propone|crea|planifica/.test(p) && topic.test(p) && /20|veinte/.test(p), hint: 'Pide diseñar el edificio de tu reto para 20 habitantes.' },
    { label: 'Restricción concreta', passed: /presupuesto|maximo|limite|no super|menos de/.test(p) && /\d/.test(p), hint: 'Añade un presupuesto o un límite numérico.' },
    { label: 'Formato de salida', passed: /tabla|lista|json|pasos|vinetas/.test(p), hint: 'Pide una tabla, lista o pasos para poder revisar la respuesta.' },
  ];
  return { score: checks.filter(c => c.passed).length, checks };
}
export class Game {
  rooms = new Map<string, Room>();
  create(now = Date.now()): Session {
    this.cleanup(now);
    assert(this.rooms.size < 200, 'El servidor está lleno. Intenta más tarde.');
    let code: string;
    do { code = randomBytes(3).toString('hex').toUpperCase(); } while (this.rooms.has(code));
    const hostToken = token();
    this.rooms.set(code, { code, hostToken, phase: 'lobby', endsAt: null, players: [], tokens: new Map(), drafts: new Map(), event: { active: false, progress: 0, goal: 50 }, log: ['La ciudad está lista para recibir habitantes.'], touchedAt: now });
    return { code, token: hostToken, kind: 'host' };
  }
  get(code: string): Room { const room = this.rooms.get(code); assert(room, 'La sala no existe o expiró.'); return room; }
  join(code: string, name: string, role: Role): Session {
    const room = this.get(code);
    assert(room.phase === 'lobby', 'La sesión ya comenzó.');
    assert(room.players.length < 20, 'La ciudad ya tiene sus 20 habitantes.');
    assert(name.length >= 2 && name.length <= 24, 'Usa un nombre de 2 a 24 caracteres.');
    assert(Object.hasOwn(ROLES, role), 'Selecciona un rol válido.');
    assert(!room.players.some(p => p.name.toLocaleLowerCase() === name.toLocaleLowerCase()), 'Ese nombre ya está en la sala.');
    const id = randomUUID(), secret = token();
    room.players.push({ id, name, role, plot: room.players.length, connected: false, credits: 20, score: 0, building: null, contributed: false });
    room.tokens.set(secret, id); room.touchedAt = Date.now();
    this.log(room, `${name} se unió a la ciudad.`);
    return { code, token: secret, kind: 'player', playerId: id };
  }
  authorize(session: Session): { room: Room; player?: Player } {
    const room = this.get(session.code);
    if (session.kind === 'host') { assert(session.token === room.hostToken, 'Credencial inválida.'); return { room }; }
    const id = room.tokens.get(session.token);
    assert(id && id === session.playerId, 'Credencial inválida.');
    return { room, player: room.players.find(p => p.id === id)! };
  }
  snapshot(session: Session): Snapshot {
    const { room, player } = this.authorize(session);
    const draft = player ? room.drafts.get(player.id) : undefined;
    return { session, room: { code: room.code, phase: room.phase, endsAt: room.endsAt, players: room.players.map(p => ({ ...p })), event: { ...room.event }, log: [...room.log], serverNow: Date.now() }, prompt: draft?.prompt ?? '', evaluation: draft?.evaluation ?? null };
  }
  presence(session: Session, connected: boolean) { const { room, player } = this.authorize(session); if (player) player.connected = connected; room.touchedAt = Date.now(); }
  act(session: Session, action: string, prompt?: unknown, now = Date.now()) {
    const { room, player } = this.authorize(session);
    if (room.phase === 'playing' && room.endsAt! <= now) { room.phase = 'finished'; this.log(room, '¡Tiempo! La ciudad termina su primera jornada.'); }
    room.touchedAt = now;
    if (['start', 'event', 'finish'].includes(action)) {
      assert(session.kind === 'host', 'Solo el presentador puede realizar esta acción.');
      if (action === 'start') {
        assert(room.phase === 'lobby' && room.players.length > 0, 'Necesitas al menos un jugador en el lobby.');
        room.phase = 'playing'; room.endsAt = now + 30 * 60_000; this.log(room, '¡Comienza la construcción! Tienen 30 minutos.');
      } else if (action === 'event') {
        assert(room.phase === 'playing', 'Inicia la sesión primero.');
        if (!room.event.active) { room.event.active = true; this.log(room, 'Evento: ¡iluminemos la plaza! Meta: 50 créditos.'); }
      } else { assert(room.phase === 'playing', 'La sesión no está en curso.'); room.phase = 'finished'; this.log(room, 'El presentador cerró la sesión.'); }
      return;
    }
    assert(player && session.kind === 'player', 'Esta acción requiere un jugador.');
    assert(room.phase === 'playing', 'La sesión no está en curso.');
    if (action === 'submit') {
      assert(typeof prompt === 'string' && prompt.trim().length >= 20 && prompt.length <= 2000, 'Escribe un prompt de 20 a 2000 caracteres.');
      assert(!player.building, 'Ya completaste tu construcción.');
      const evaluation = evaluate(prompt, player.role); room.drafts.set(player.id, { prompt, evaluation }); player.score = evaluation.score;
    } else if (action === 'build') {
      if (player.building) return;
      assert(player.score >= 3, 'Necesitas al menos 3 de 4 criterios para construir.');
      assert(player.credits >= 10, 'Necesitas 10 créditos.');
      player.credits -= 10; player.building = ROLES[player.role].building;
      this.log(room, `${player.name} construyó: ${player.building}.`);
    } else if (action === 'contribute') {
      assert(room.event.active, 'El evento aún no está abierto.');
      if (player.contributed || room.event.progress >= room.event.goal) return;
      assert(player.credits >= 5, 'Necesitas 5 créditos.');
      player.credits -= 5; player.contributed = true; room.event.progress += 5;
      this.log(room, room.event.progress >= room.event.goal ? '¡Plaza iluminada! La ciudad logró la meta colectiva.' : `${player.name} aportó 5 créditos a la plaza.`);
    } else throw new GameError('Acción desconocida.');
  }
  tick(now = Date.now()): string[] {
    const changed: string[] = [];
    for (const room of this.rooms.values()) if (room.phase === 'playing' && room.endsAt! <= now) { room.phase = 'finished'; this.log(room, '¡Tiempo! La ciudad termina su primera jornada.'); changed.push(room.code); }
    return changed;
  }
  cleanup(now = Date.now()) { for (const [code, room] of this.rooms) if (now - room.touchedAt > 2 * 60 * 60_000) this.rooms.delete(code); }
  private log(room: Room, message: string) { room.log = [message, ...room.log].slice(0, 12); }
}
