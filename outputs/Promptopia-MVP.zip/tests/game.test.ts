import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Game, evaluate } from '../lib/game';
const good = 'Actúa como arquitecta. Diseña una biblioteca para 20 habitantes con presupuesto máximo de 1000 créditos. Responde en una tabla.';

test('20 parcelas únicas, plaza 21 rechazada, roles y nombres validados', () => {
  const game = new Game(), host = game.create();
  const players = Array.from({ length: 20 }, (_, i) => game.join(host.code, `Persona ${i}`, 'urbanista'));
  assert.equal(new Set(players.map(s => game.authorize(s).player!.plot)).size, 20);
  assert.throws(() => game.join(host.code, 'Extra', 'ingeniero'), /20 habitantes/);
  const empty = game.create();
  assert.throws(() => game.join(empty.code, 'Ana', 'toString' as never), /rol válido/);
  game.join(empty.code, 'Ana', 'urbanista');
  assert.throws(() => game.join(empty.code, 'ana', 'urbanista'), /nombre/);
});
test('rúbrica reproducible y sensible al reto', () => {
  assert.equal(evaluate(good, 'urbanista').score, 4);
  assert.equal(evaluate(good, 'ecologista').score, 3);
  assert.equal(evaluate('hola mundo', 'urbanista').score, 0);
});
test('autoridad, créditos, construcción y evento idempotentes', () => {
  const game = new Game(), host = game.create();
  const player = game.join(host.code, 'Ana', 'urbanista');
  assert.throws(() => game.act(player, 'start'), /presentador/);
  assert.throws(() => game.act(player, 'submit', good), /no está en curso/);
  game.act(host, 'start');
  assert.throws(() => game.act(player, 'build'), /3 de 4/);
  assert.throws(() => game.act(player, 'submit', 123), /2000/);
  game.act(player, 'submit', good); game.act(player, 'build'); game.act(player, 'build');
  assert.equal(game.authorize(player).player!.credits, 10);
  assert.throws(() => game.act(player, 'contribute'), /no está abierto/);
  game.act(host, 'event'); game.act(player, 'contribute'); game.act(player, 'contribute');
  assert.equal(game.authorize(player).player!.credits, 5);
  assert.equal(game.snapshot(host).room.event.progress, 5);
  assert.throws(() => game.act({ ...host, token: 'forged' }, 'finish'), /Credencial/);
  assert.throws(() => game.authorize({ ...player, playerId: 'someone-else' }), /Credencial/);
  assert.equal(game.snapshot(host).evaluation, null);
  assert.equal(game.snapshot(host).prompt, '');
  assert.equal(JSON.stringify(game.snapshot(player).room).includes(player.token), false);
  game.act(host, 'finish');
  assert.throws(() => game.act(player, 'submit', good), /no está en curso/);
});
test('evento colectivo llega a la meta sin sobrecobrar', () => {
  const game = new Game(), host = game.create();
  const players = Array.from({ length: 20 }, (_, i) => game.join(host.code, `Jugador ${i}`, 'ingeniero'));
  game.act(host, 'start'); game.act(host, 'event');
  for (const player of players) game.act(player, 'contribute');
  assert.equal(game.snapshot(host).room.event.progress, 50);
  assert.equal(game.authorize(players[10]).player!.credits, 20);
});
test('reconexión conserva parcela y el reloj impide acciones tardías', () => {
  const game = new Game(), host = game.create();
  const player = game.join(host.code, 'Ana', 'urbanista');
  game.presence(player, true); game.presence(player, false); game.presence(player, true);
  assert.equal(game.snapshot(host).room.players.length, 1);
  assert.equal(game.authorize(player).player!.plot, 0);
  const now = Date.now(); game.act(host, 'start', undefined, now);
  assert.throws(() => game.join(host.code, 'Tarde', 'ingeniero'), /ya comenzó/);
  assert.throws(() => game.act(player, 'submit', good, now + 30 * 60_000), /no está en curso/);
  assert.equal(game.snapshot(host).room.phase, 'finished');
});
