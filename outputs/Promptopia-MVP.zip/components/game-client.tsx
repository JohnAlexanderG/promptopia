'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { io, type Socket } from 'socket.io-client';
import CityScene from './city-scene';
import Journey from './journey';
import { MotionConfig } from 'motion/react';
import { ROLES, type Role, type Reply, type Snapshot, type Session, type Action } from '@/lib/types';

const STORAGE = 'promptopia-session-v1';
const buildingIcon: Record<Role, string> = { urbanista: '📚', ingeniero: '☀️', ecologista: '🌳' };
export default function GameClient() {
  const socket = useRef<Socket | null>(null);
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [connected, setConnected] = useState(false);
  const [ready, setReady] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [role, setRole] = useState<Role>('urbanista');
  const [prompt, setPrompt] = useState('');
  const [now, setNow] = useState(Date.now());
  const clockOffset = useRef(0);
  const savedSession = useRef<Session | null>(null);

  const receive = useCallback((data: Snapshot) => {
    clockOffset.current = data.room.serverNow - Date.now();
    setNow(Date.now());
    setSnapshot(data); savedSession.current = data.session;
    try { sessionStorage.setItem(STORAGE, JSON.stringify(data.session)); } catch { /* Current connection still works. */ }
  }, []);
  useEffect(() => {
    setCode(new URLSearchParams(window.location.search).get('sala')?.toUpperCase().slice(0, 6) ?? '');
    try { savedSession.current = JSON.parse(sessionStorage.getItem(STORAGE) || 'null'); } catch { savedSession.current = null; }
    const client = io({ autoConnect: false }); socket.current = client;
    client.on('room:state', receive);
    client.on('connect', () => {
      setConnected(true); setError('');
      if (!savedSession.current) { setReady(true); return; }
      client.timeout(8000).emit('room:action', { action: 'resume', session: savedSession.current }, (err: Error | null, reply: Reply) => {
        setReady(true);
        if (err) { setError('No se pudo recuperar la sesión. Reintenta o cambia de sala.'); return; }
        if (!reply?.ok) { setError(reply?.error ?? 'No se recibió la sesión.'); return; }
        receive(reply.data); setPrompt(reply.data.prompt);
      });
    });
    client.on('disconnect', () => { setConnected(false); setReady(false); });
    client.on('connect_error', () => { setError('No hay conexión con el servidor. Intentando reconectar…'); setReady(true); });
    client.connect();
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => { clearInterval(interval); client.disconnect(); socket.current = null; };
  }, [receive]);

  async function act(action: Action, extra: Record<string, unknown> = {}) {
    if (!socket.current?.connected || pending || !ready) return;
    setPending(true); setError(''); setNotice('');
    socket.current.timeout(8000).emit('room:action', { action, ...extra }, (err: Error | null, reply: Reply) => {
      setPending(false);
      if (err) { setError('No llegó la confirmación. El estado se recuperará al reconectar; puedes reintentar.'); return; }
      if (!reply?.ok) { setError(reply?.error ?? 'No se recibió la confirmación.'); return; }
      receive(reply.data);
      if (action === 'submit') setNotice('Evaluación guardada. Revisa los criterios debajo.');
    });
  }
  function reset() { try { sessionStorage.removeItem(STORAGE); } catch {} window.location.assign('/'); }
  async function copyInvite() {
    try { await navigator.clipboard.writeText(`${window.location.origin}/?sala=${snapshot!.room.code}`); setNotice('Enlace copiado. Compártelo por el chat de Meet.'); }
    catch { setNotice(`Comparte esta dirección y el código ${snapshot!.room.code}.`); }
  }
  const room = snapshot?.room;
  const host = snapshot?.session.kind === 'host';
  const me = room?.players.find(p => p.id === snapshot?.session.playerId);
  const seconds = room?.endsAt ? Math.max(0, Math.ceil((room.endsAt - now - clockOffset.current) / 1000)) : 1800;
  const time = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  const built = room?.players.filter(p => p.building).length ?? 0;
  const disabled = !connected || !ready || pending;

  return <MotionConfig reducedMotion="user"><div className="shell">
    <header className="topbar"><a className="brand" href="/" aria-label="Promptopia, inicio"><span className="brand-icon">▦</span> promptopia<span className="brand-dot">.</span></a><div className="top-meta"><span className={`status-dot ${connected ? 'online' : ''}`} />{connected ? 'En línea' : 'Reconectando'}<span className="edition">LABORATORIO DE IDEAS / 01</span></div></header>
    {error && <div className="alert" role="alert">{error} <button className="text-button" onClick={reset}>Cambiar de sala</button></div>}
    {notice && <div className="notice" role="status">{notice}</div>}
    {!room ? <main className="landing">
      <section className="intro"><span className="eyebrow">UNA EXPERIENCIA PARA CONSTRUIR JUNTOS</span><h1>Tu próxima idea<br />puede ser <em>una ciudad.</em></h1><p>Tienes una parcela y 20 créditos. Escribe un buen prompt, desbloquea tu edificio y construye una ciudad con tu equipo.</p><div className="intro-facts"><span><b>20</b> habitantes</span><span><b>30</b> minutos</span><span><b>01</b> ciudad compartida</span></div><CityScene preview /><p className="small-note">Explora la isla y prueba una construcción antes de entrar.</p></section>
      <section className="entry-card"><div className="entry-badge">TU AVENTURA EMPIEZA AQUÍ</div><span className="eyebrow">TU PARCELA TE ESPERA</span><h2>Entra a la ciudad</h2><p className="muted">Pide el código al presentador y elige tu papel.</p><form onSubmit={e => { e.preventDefault(); void act('join', { code: code.trim(), name: name.trim(), role }); }}><label htmlFor="code">Código de la sala</label><input id="code" placeholder="Ej. A1B2C3" value={code} maxLength={6} minLength={6} pattern="[A-Fa-f0-9]{6}" required onChange={e => setCode(e.target.value.toUpperCase())} className="code-input" autoComplete="off" /><label htmlFor="name">Tu nombre</label><input id="name" placeholder="¿Cómo te llamas?" value={name} minLength={2} maxLength={24} required onChange={e => setName(e.target.value)} autoComplete="given-name" /><label htmlFor="role">Tu rol en la ciudad</label><select id="role" value={role} onChange={e => setRole(e.target.value as Role)}>{Object.entries(ROLES).map(([key, value]) => <option value={key} key={key}>{value.icon} {value.label} · {value.building}</option>)}</select><button className="button primary full" disabled={disabled} type="submit">{pending ? 'Conectando…' : 'Encontrar mi parcela →'}</button></form><Journey /><div className="entry-divider">¿Vas a guiar la experiencia?</div><button className="button secondary full" disabled={disabled} onClick={() => void act('create')}>Crear sala de presentador</button><p className="small-note">Sin cuentas · Hasta 20 jugadores · Evaluación por reglas</p></section>
    </main> : <main className="workspace">
      <section className="session-heading"><div><span className="eyebrow">{host ? 'VISTA PRESENTADOR' : `HOLA, ${me?.name.toUpperCase()}`} / SESIÓN COMPARTIDA</span><h1>La ciudad de las ideas<span className="brand-dot">.</span></h1><p className="muted">{room.phase === 'lobby' ? 'Cada habitante, una parcela. Todo empieza con un buen prompt.' : room.phase === 'finished' ? 'Una ciudad que construyeron juntos. Es momento de compartir lo aprendido.' : 'Escribe, mejora y construye. Cada idea hace crecer nuestra ciudad.'}</p></div><div className="room-code"><span>CÓDIGO DE SALA</span><b>{room.code}</b><button onClick={copyInvite} className="text-button">Copiar invitación ↗</button></div></section>
      <div className="stat-strip"><div><span className="status-dot online" /><b>{room.players.length}/20</b><span>habitantes · {room.players.filter(p => p.connected).length} en línea</span></div><div><b>{built}/20</b><span>construcciones</span></div><div><b className={seconds < 60 ? 'urgent' : ''}>{room.phase === 'finished' ? 'Finalizada' : time}</b><span>{room.phase === 'lobby' ? 'listos para empezar' : 'tiempo de sesión'}</span></div><span className={`phase ${room.phase}`}>{room.phase === 'lobby' ? 'EN EL LOBBY' : room.phase === 'playing' ? 'EN CONSTRUCCIÓN' : 'SESIÓN CERRADA'}</span></div>
      <Journey room={room} me={me} host={host}/><div className="game-layout"><section className="city-panel"><div className="panel-heading"><div><span className="eyebrow">NUESTRO TERRITORIO</span><h2>Una parcela, mil posibilidades</h2></div><span className="subtle">20 parcelas · actualización en vivo</span></div>
        <CityScene room={room} me={me} />
        <section className="activity"><h3>Así crece la ciudad <span>EN VIVO</span></h3><ul>{room.log.slice(0, 5).map((item, i) => <li key={`${i}-${item}`}><span>↗</span>{item}</li>)}</ul></section>
      </section>
      <aside className="side-panel">
        {host ? <section className="card"><span className="eyebrow">LA MESA DEL PRESENTADOR</span><h2>{room.phase === 'lobby' ? 'Reúne a tu equipo' : room.phase === 'finished' ? 'Lo que construimos' : 'Guía la experiencia'}</h2><p className="muted">{room.phase === 'lobby' ? 'Comparte la invitación en Meet. Cuando estén listos, inicia el reloj de 30 minutos.' : room.phase === 'finished' ? `${built} construcciones y ${room.event.progress} créditos para la plaza. Invita a compartir cómo mejoraron sus prompts.` : 'Comparte este tablero en Meet. Abre el evento cuando la ciudad empiece a tomar forma.'}</p>{room.phase === 'lobby' && <button className="button primary full" disabled={disabled || !room.players.length} onClick={() => void act('start')}>Iniciar sesión · 30 min →</button>}{room.phase === 'playing' && <><button className="button primary full" disabled={disabled || room.event.active} onClick={() => void act('event')}>{room.event.active ? 'Evento colectivo abierto' : 'Abrir evento colectivo ✳'}</button><button className="button secondary full" disabled={disabled} onClick={() => { if (window.confirm('¿Cerrar la sesión para todos? Ya no podrán construir.')) void act('finish'); }}>Cerrar sesión</button></>}<div className="guide"><b>Guion sugerido para Meet</b><p>00–05 · Bienvenida y roles<br />05–10 · Anatomía de un prompt<br />10–20 · Construir la ciudad<br />20–25 · Desafío colectivo<br />25–30 · Reflexión compartida</p></div></section> : me && <section className="card" id="player-workshop"><span className="eyebrow">TU TALLER / PARCELA {String(me.plot + 1).padStart(2, '0')}</span><div className="workshop-title"><h2>{ROLES[me.role].label}</h2><span className="credits">◈ {me.credits}</span></div><p className="challenge">{ROLES[me.role].challenge}</p>{room.phase === 'lobby' ? <div className="waiting"><span>◎</span><b>Tu lugar está reservado</b><p>Esperamos a que el presentador inicie. Mientras tanto, piensa en el rol, contexto, límites y formato de tu prompt.</p></div> : me.building ? <div className="success"><span>{buildingIcon[me.role]}</span><h3>¡Una idea hecha ciudad!</h3><p>Construiste {me.building.toLowerCase()} con un prompt de {me.score}/4. Comparte en Meet qué criterio te ayudó más.</p></div> : <><label htmlFor="prompt">Tu prompt</label><textarea id="prompt" rows={7} placeholder="Actúa como… Diseña… Ten en cuenta… Presenta el resultado en…" value={prompt} maxLength={2000} disabled={room.phase !== 'playing'} onChange={e => setPrompt(e.target.value)} /><div className="editor-meta"><span>Rúbrica por reglas · sin IA</span><span>{prompt.length}/2000</span></div><button className="button primary full" disabled={disabled || room.phase !== 'playing' || prompt.trim().length < 20} onClick={() => void act('submit', { prompt })}>Evaluar mi prompt →</button>{snapshot.evaluation && <div className="evaluation"><h3>Tu evaluación <span>{snapshot.evaluation.score}/4</span></h3><p className="subtle">Evaluación del último envío; evalúa de nuevo si lo editas.</p>{snapshot.evaluation.checks.map(check => <div className={`criterion ${check.passed ? 'passed' : ''}`} key={check.label}><b>{check.passed ? '✓' : '○'} {check.label}</b>{!check.passed && <small>{check.hint}</small>}</div>)}<button className="button secondary full" disabled={disabled || room.phase !== 'playing' || snapshot.evaluation.score < 3} onClick={() => void act('build')}>Construir {ROLES[me.role].building.toLowerCase()} · 10 ◈</button></div>}</>}{room.phase === 'finished' && <p className="small-note">La sesión terminó. Tu ciudad queda disponible para verla.</p>}</section>}
        <section className="card event-card"><span className="eyebrow">MISIÓN COLECTIVA</span><h2>Iluminemos la plaza <span>✳</span></h2><p className="muted">Cada aporte enciende una parte de la ciudad. Juntos necesitamos 50 créditos.</p><div className="progress-label"><b>{room.event.progress} / {room.event.goal} ◈</b><span>{room.event.progress >= room.event.goal ? '¡Lo logramos!' : room.event.active ? 'Evento abierto' : 'Próximamente'}</span></div><progress value={room.event.progress} max={room.event.goal} aria-label="Progreso del evento colectivo" />{me && <button className="button secondary full" disabled={disabled || !room.event.active || room.phase !== 'playing' || me.contributed || room.event.progress >= room.event.goal || me.credits < 5} onClick={() => void act('contribute')}>{me.contributed ? '✓ Ya aportaste a la plaza' : 'Aportar 5 créditos ◈'}</button>}<p className="small-note">Un aporte por habitante. El presentador abre el evento.</p></section>
      </aside></div>
    </main>}
    <footer><span>PROMPTOPIA · APRENDEMOS CONSTRUYENDO</span><span>Las grandes ciudades empiezan con buenas preguntas.</span></footer>
  </div></MotionConfig>;
}
